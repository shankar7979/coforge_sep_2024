package com.example.model;

import lombok.Data;

import java.util.Objects;

@Data
public class Employee {
    private int id;
    private  String name;
    private  float salary;

}
