package com.example.exception;

public class EmployeeException extends  RuntimeException{
    public EmployeeException(String message) {
        super(message);
    }
}
