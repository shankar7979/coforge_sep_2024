package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRest1Application {
	public static void main(String[] args) {
		SpringApplication.run(SpringRest1Application.class, args);
	}
}
/*
{
    "id":77681,
    "name":"hari sharma",
    "salary":56000,
    "dob": "1997-11-20"
}
*/