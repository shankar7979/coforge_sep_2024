export class Person{
    id:number=0;
    name:string='';
    salary:number=0;
    dob:Date=new Date();


}