export const prddata = [
    {
        "id": 10001, "name": "shoe", "cost": 1200, "mfd": new Date('2023-1-12')
    },

    {
        "id": 10002, "name": "pant", "cost": 1500, "mfd": new Date('2023-1-26')
    },
    {
        "id": 10003, "name": "shirt", "cost": 800, "mfd": new Date('2023-8-21')
    },
    {
        "id": 10004, "name": "trouser", "cost": 700, "mfd": new Date('2022-12-30')
    },
    {
        "id": 10005, "name": "mobile", "cost": 20000, "mfd": new Date('2022-6-26')
    },
    {
        "id": 10006, "name": "freeze", "cost": 25000, "mfd": new Date('2023-3-30')
    },
    {
        "id": 10007, "name": "burger", "cost": 300, "mfd": new Date()
    },
    {
        "id": 10008, "name": "pizza", "cost": 500, "mfd": new Date()
    }
]

