export class Book {
    isbn: number = 0;
    bname: string = '';
    cost: number = 0;
}