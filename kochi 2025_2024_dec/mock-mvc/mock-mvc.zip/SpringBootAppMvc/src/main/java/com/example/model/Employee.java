package com.example.model;

import lombok.Data;

@Data
public class Employee {

	public  int id;
	public  String name;
	public  float salary;
}
