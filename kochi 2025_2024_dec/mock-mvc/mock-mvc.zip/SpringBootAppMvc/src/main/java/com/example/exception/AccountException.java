package com.example.exception;

public class AccountException extends RuntimeException {

	public AccountException(String s) {
		super(s);
	}

}
