package com.bezkoder.spring.r2dbc.mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootR2dbcMysqlExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
