package com.hendisantika.springbootemail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootEmailApplicationTests {

    @Test
    void contextLoads() {
    }

}
