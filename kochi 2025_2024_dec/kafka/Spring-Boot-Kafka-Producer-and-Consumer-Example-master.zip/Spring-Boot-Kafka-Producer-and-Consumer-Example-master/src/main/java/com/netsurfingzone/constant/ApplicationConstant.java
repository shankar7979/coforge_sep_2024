package com.netsurfingzone.constant;

public class ApplicationConstant {
	public static final String KAFKA_LOCAL_SERVER_CONFIG = "localhost:9092";
	public static final String GROUP_ID_STRING = "group1";
	public static final String TOPIC_NAME = "test1";
	public static final String KAFKA_LISTENER_CONTAINER_FACTORY = "kafkaListenerContainerFactory";
	public static final String GROUP_ID_JSON = "group-id-json-1";
	
	/*
	public static final String KAFKA_LOCAL_SERVER_CONFIG = "localhost:9092";
	public static final String GROUP_ID_STRING = "group-id-string-1";
	public static final String TOPIC_NAME = "netsurfingzone-topic-1";
	public static final String KAFKA_LISTENER_CONTAINER_FACTORY = "kafkaListenerContainerFactory";
	public static final String GROUP_ID_JSON = "group-id-json-1";
	*/
}
