# Spring Boot Kafka Producer and Consumer Example
Spring Boot Kafka Producer and Consumer Example tutorial from scratch.
https://www.javatute.com/kafka/spring-boot-kafka-producer-and-consumer-example-step-by-step-guide/

This tutorial covers below points.

1. How to install apache kafka.
2. How to start zookeeper and kafka.
3. How to create topic.
4. How to configure spring and apache kafka.
5. How to create kafka producer to send string and json type messages.
6. How to create kafka consumer to receive string and json message.



