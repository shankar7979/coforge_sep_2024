package io.abc.app.enumeration;

public enum Role {

    USER,
    ADMIN
}
