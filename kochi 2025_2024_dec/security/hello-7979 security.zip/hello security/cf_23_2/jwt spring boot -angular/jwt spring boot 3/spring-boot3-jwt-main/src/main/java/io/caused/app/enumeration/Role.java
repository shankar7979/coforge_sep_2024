package io.caused.app.enumeration;

public enum Role {

    USER,
    ADMIN
}
