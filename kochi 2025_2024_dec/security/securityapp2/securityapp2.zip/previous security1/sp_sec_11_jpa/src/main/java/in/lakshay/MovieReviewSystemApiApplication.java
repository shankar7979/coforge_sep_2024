package in.lakshay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieReviewSystemApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieReviewSystemApiApplication.class, args);
	}

}

//insert into users (user_name,password) values('ram kumar','$2a$12$nq3xL/pOmid1K1QWS/peDOk6OIOkIjFAWooTH8RnSPDi9o7tVDOjm');
//https://bcrypt-generator.com/

