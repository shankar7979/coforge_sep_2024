package com.example.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App1Main {
    public static void main(String[] args) {
        SpringApplication.run(App1Main.class,args);
    }
}
