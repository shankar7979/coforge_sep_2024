import { RestapiService } from './restapi-service';

describe('RestapiService', () => {
  it('should create an instance', () => {
    expect(new RestapiService()).toBeTruthy();
  });
});
