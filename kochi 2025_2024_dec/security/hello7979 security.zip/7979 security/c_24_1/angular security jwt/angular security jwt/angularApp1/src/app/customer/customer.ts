export class Customer{
    customerId:number;
    customerName:string;
    customerSalary:number;

    constructor(){
        this.customerId=10000;
        this.customerName="suresh kumar";
        this.customerSalary=34000;
    }
}