package fr.mossaab.security.enums;

public enum TokenType {
    BEARER
}
