package com.senai.engSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EngSecurityApplication {

//	Turma de Engenharia de Software 6
	public static void main(String[] args) {
		SpringApplication.run(EngSecurityApplication.class, args);
	}

}
