package com.nikhil.backend.controller;

import com.nikhil.backend.entity.Goal;
import com.nikhil.backend.security.JwtUtil;
import com.nikhil.backend.service.GoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/goals")
public class GoalController {

    @Autowired
    private GoalService goalService;

    @Autowired
    private JwtUtil jwtUtil;

    @RequestMapping(method = RequestMethod.OPTIONS)
    public ResponseEntity<?> handleOptions() {
        return ResponseEntity.ok().build();
    }

    @GetMapping
    public ResponseEntity<List<Goal>> getAllGoals(@RequestHeader("Authorization") String token) {
        System.out.println("Authorization Header: " + token);
        System.out.println("Received Token: " + token); // Debugging log

        if (token != null && token.startsWith("Bearer ")) {
            token = token.substring(7);
            System.out.println("Token after extraction: " + token);// Remove "Bearer " prefix
        } else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null); // Invalid token format
        }

        String username = jwtUtil.extractUsername(token); // Extract username from the token
        if (username == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null); // Token issue
        }

        List<Goal> goals = goalService.getUserGoals(username);
        System.out.println(goals);
        return ResponseEntity.ok(goals);
    }


    @PostMapping
    public ResponseEntity<Goal> addGoal(@RequestHeader("Authorization") String token, @RequestBody String goalDescription) {
        System.out.println("Received Token: " + token);
        String username = jwtUtil.extractUsername(token.substring(7));
        Goal goal = goalService.createGoal(username, goalDescription);
        return ResponseEntity.status(HttpStatus.CREATED).body(goal);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Goal> updateGoal(@RequestHeader("Authorization") String token, @PathVariable Long id, @RequestBody String goalDescription) {
        System.out.println("Received Token: " + token);
        String username = jwtUtil.extractUsername(token.substring(7));
        Goal updatedGoal = goalService.updateGoal(id, goalDescription);
        return ResponseEntity.ok(updatedGoal);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGoal(@RequestHeader("Authorization") String token, @PathVariable Long id) {
        System.out.println("Received Token: " + token);
        String username = jwtUtil.extractUsername(token.substring(7));
        goalService.deleteGoal(id);
        return ResponseEntity.noContent().build();
    }
}