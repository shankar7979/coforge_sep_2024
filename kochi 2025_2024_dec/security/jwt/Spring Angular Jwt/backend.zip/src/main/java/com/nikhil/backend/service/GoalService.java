package com.nikhil.backend.service;

import com.nikhil.backend.entity.Goal;
import com.nikhil.backend.entity.User;
import com.nikhil.backend.repository.GoalRepository;
import com.nikhil.backend.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GoalService {

    @Autowired
    private GoalRepository goalRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Goal> getUserGoals(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return goalRepository.findByUser(user);
    }

    public Goal createGoal(String username, String goalDescription) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        Goal goal = new Goal();
        goal.setUser(user);
        goal.setGoal(goalDescription);
        return goalRepository.save(goal);
    }

    public Goal updateGoal(Long goalId, String goalDescription) {
        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new EntityNotFoundException("Goal not found"));
        goal.setGoal(goalDescription);
        return goalRepository.save(goal);
    }

    public void deleteGoal(Long goalId) {
        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new EntityNotFoundException("Goal not found"));
        goalRepository.delete(goal);
    }

}
