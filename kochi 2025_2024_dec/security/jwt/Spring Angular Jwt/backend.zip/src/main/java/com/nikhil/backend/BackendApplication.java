package com.nikhil.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
    }

}
/*
post 
http://localhost:8080/auth/register
{
  "username":"suresh kumar",
   "password":"1234",
   "confirmPassword":"1234"
}

post 
http://localhost:8080/auth/register
/*
{
  "username":"suresh kumar",
   "password":"1234",
   "confirmPassword":"1234"
}
it will generate jwt token

http://localhost:4200/login
  "username":"suresh kumar",
   "password":"1234",

*/



