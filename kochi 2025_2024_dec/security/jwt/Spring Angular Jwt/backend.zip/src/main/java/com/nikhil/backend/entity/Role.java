package com.nikhil.backend.entity;

public enum Role {
    USER, ADMIN
}
