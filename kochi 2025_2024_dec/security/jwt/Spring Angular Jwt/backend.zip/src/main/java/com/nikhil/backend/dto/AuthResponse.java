package com.nikhil.backend.dto;

public class AuthResponse {
    private String token;

    public String getToken() {
        return token;
    }

    public AuthResponse() {
    }

    public AuthResponse(String token) {
        this.token = token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
