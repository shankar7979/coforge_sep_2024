/*
post 
http://localhost:8080/auth/register
{
  "username":"suresh kumar",
   "password":"1234",
   "confirmPassword":"1234"
}

post 
http://localhost:8080/auth/register
/*
{
  "username":"suresh kumar",
   "password":"1234",
   "confirmPassword":"1234"
}
it will generate jwt token

http://localhost:4200/login
  "username":"suresh kumar",
   "password":"1234",

*/



