export interface Goal {
    id: number;
    goal: string;
    createdAt: string;
 
}
