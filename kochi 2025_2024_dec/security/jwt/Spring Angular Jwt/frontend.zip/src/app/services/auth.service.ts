import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiURL = 'http://localhost:8080/auth';
  private currentUserSubject : BehaviorSubject<any>;

  constructor(private http: HttpClient,private router: Router) { 
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser') || '{}'));
  }

  login(credentials:{username: string; password:string}): Observable<any>{
    return this.http.post<any>(`${this.apiURL}/login`, credentials)
    .pipe(tap(response => {
      localStorage.setItem('currentUser', JSON.stringify({
        token: response.token
      }))
    }))
  }
  register(user: { username: string; password: string }) {
    return this.http.post(`${this.apiURL}/register`, user, { responseType: 'text' });
  }
  
  getToken(): string | null{
    return JSON.parse(localStorage.getItem('currentUser') || '{}')?.token || null;
  }

  isAuthenticated(): boolean{
    return !!this.getToken();
  }

  logout(): void{
    localStorage.removeItem('currentUser');
    this.router.navigate(['/login']);
  }

}
