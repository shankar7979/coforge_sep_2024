import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { Goal } from '../models/goal';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class GoalService {
  private apiUrl = 'http://localhost:8080/goals';

  constructor(private http: HttpClient, private authService: AuthService) {}

  getGoals(): Observable<Goal[]> {
    const token = this.authService.getToken();
  
    if (!token) {
      console.error("No token found, user might not be authenticated.");
      return throwError(() => new Error("Authentication token is missing"));
    }
  
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  
    console.log("Sending Token: ", token);
  
    return this.http.get<Goal[]>(this.apiUrl, { headers, withCredentials: true })
      .pipe(
        catchError((error: HttpErrorResponse) => {
          console.error("Error fetching goals:", error);
          return throwError(() => new Error("Failed to fetch goals"));
        })
      );
  }

  addGoal(goalDescription: string): Observable<Goal> {
    const token = this.authService.getToken();
    console.log("Sending Token: ", token);
    return this.http.post<Goal>(this.apiUrl, goalDescription, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${token}`)
        .set('Content-Type', 'application/json'), // Send plain text
      responseType: 'json'
    });
  }

  updateGoal(goalId: number, goalDescription: string): Observable<Goal> {
    const token = this.authService.getToken();
    return this.http.put<Goal>(`${this.apiUrl}/${goalId}`, goalDescription, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${token}`)
        .set('Content-Type', 'application/json'), // Send plain text
      responseType: 'json'
    });
  }

  deleteGoal(goalId: number): Observable<void> {
    const token = this.authService.getToken();
    return this.http.delete<void>(`${this.apiUrl}/${goalId}`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    });
  }
}
