import { Component, OnInit } from '@angular/core';
import { GoalService } from 'src/app/services/goal.service';
import { AuthService } from 'src/app/services/auth.service'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-goals',
  templateUrl: './goals.component.html',
  styleUrls: ['./goals.component.css']
})
export class GoalsComponent implements OnInit {
  goals: any[] = [];
  newGoal: string = '';
  errorMessage: string = '';

  constructor(private goalService: GoalService, private authService: AuthService,private router: Router) {}

  ngOnInit() {
    this.loadGoals();
  }

  loadGoals() {
    this.goalService.getGoals().subscribe({
      next: (goals) => {
        console.log(goals);  
        this.goals = goals;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load goals';
      }
    });
  }

  addGoal() {
    if (this.newGoal.trim()) {
      this.goalService.addGoal(this.newGoal).subscribe({
        next: (goal) => {
          this.goals.push(goal);
          this.newGoal = '';
        },
        error: (err) => {
          this.errorMessage = 'Failed to add goal';
        }
      });
    }
  }

  updateGoal(goal: any) {
    const updatedGoalDescription = prompt('Update goal:', goal.goal);
    if (updatedGoalDescription) {
      this.goalService.updateGoal(goal.id, updatedGoalDescription).subscribe({
        next: (updatedGoal) => {
          goal.goal = updatedGoal.goal;
        },
        error: (err) => {
          this.errorMessage = 'Failed to update goal';
        }
      });
    }
  }

  deleteGoal(goalId: number) {
    this.goalService.deleteGoal(goalId).subscribe({
      next: () => {
        this.goals = this.goals.filter((goal) => goal.id !== goalId);
      },
      error: (err) => {
        this.errorMessage = 'Failed to delete goal';
      }
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']); // Redirect to login page
  }
}
