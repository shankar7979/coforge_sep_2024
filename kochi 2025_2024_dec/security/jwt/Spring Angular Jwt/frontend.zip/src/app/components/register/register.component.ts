import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  username: string = '';
  password: string = '';
  confirmPassword: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  register() {
    if (this.password !== this.confirmPassword) {
      this.errorMessage = 'Passwords do not match!';
      return;
    }
  
    const registerRequest = {
      username: this.username,
      password: this.password,
      confirmPassword: this.confirmPassword
    };
  
    this.authService.register(registerRequest)
      .subscribe({
        next: (response) => {
          // Successful registration
          this.router.navigate(['/login']);
        },
        error: (err) => {
          // Log the full error to the console for debugging
          console.error('Error response:', err);
          
          // Check if the error status is 400 (Bad Request) or other error codes
          if (err.status === 400) {
            this.errorMessage = err.error || 'Registration failed';
          } else {
            this.errorMessage = 'An unexpected error occurred. Please try again.';
          }
        }
      });
  }
  
  
}
