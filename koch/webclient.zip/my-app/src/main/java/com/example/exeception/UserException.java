package com.example.exeception;

public class UserException  extends RuntimeException{

    public UserException(String message) {
        super(message);
    }
}
