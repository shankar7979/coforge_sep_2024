package com.cts.model;

public class Hello {

	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
		
			for (int j = 0; j < args.length; j++) {
				
			}
		}
		
		
	}
	
	void hello() {
		
	}
	void addition(int a, int b) {
		
	}
	
	
}
