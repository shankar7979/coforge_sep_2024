package hardcouple;

public class Car {
	
void start() {
	System.out.println("Car starts ");
}
}
