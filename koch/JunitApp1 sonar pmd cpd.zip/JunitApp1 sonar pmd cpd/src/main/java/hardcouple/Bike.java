package hardcouple;

public class Bike {

void start() {
	System.out.println("Bike starts ");
}
}
