package hardcouple;

public class Traveller {

	public static void main(String[] args) {
		Car car=new Car();
		Bike bike=new Bike();
		
		car.start();
		bike.start();
		
	}
}

/*

Bike  \  Vechicle Interface
Car    /

*/