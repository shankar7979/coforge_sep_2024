package loosecouple;

public interface Vehicle {

	void start();
	
}
