package loosecouple;

public class Bike  implements Vehicle{

	@Override
	public void start() {
		System.out.println("bike starts");
	}

}
