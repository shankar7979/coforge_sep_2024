package loosecouple;

public class Car  implements Vehicle{

	@Override
	public void start() {
		System.out.println("car starts");
	}

}
