package com.cts.model;

public class Calculation {

	public int sum(int a , int b) {
		return a+b;
	}
	
	public int subtraction(int a , int b) {
		return a-b;
	}
	
	public int multiplication(int a , int b) {
		return a*b;
	}
	
	public int division(int a , int b) {
		return a/b;
	}
	
}
