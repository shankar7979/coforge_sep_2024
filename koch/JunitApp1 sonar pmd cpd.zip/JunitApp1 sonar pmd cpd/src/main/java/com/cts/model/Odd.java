package com.cts.model;
public class Odd {

	public boolean checkOdd(int a) {
		return a%2!=0;
	}
	
}
