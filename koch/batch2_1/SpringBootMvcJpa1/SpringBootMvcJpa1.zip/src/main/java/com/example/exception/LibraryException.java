package com.example.exception;

public class LibraryException  extends RuntimeException{

	public LibraryException(String s) {
		super(s);
	}
}
