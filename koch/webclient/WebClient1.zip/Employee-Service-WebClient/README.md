# Calling REST Services with WebClient at Spring Boot application (Spring Boot 3.3.4, Java 17, MySQL, Postman, IntelliJ IDEA)

## Will create 2 demo project(address service & employee service) and will hit api explaining below concepts
Address Service Code: https://github.com/TheDipDeveloper/Address-Service-WebClient

Employee Service Code: https://github.com/TheDipDeveloper/Employee-Service-WebClient
### 1. What is WebClient and its real-life use case?
### 2. Create 2 different spring boot project with spring initializer
### 3. Different WebClient methods and their practical use case
### 4. Will follow the standard Software Development methodology in our Application
### 5. A practical demo of consuming the Address Service REST API using Employee Service
### 6. Can we use RestTemplate instead of WebClient?
# Please SUBSCRIBE - LIKE - SHARE the video
## Please provide feedback on COMMENT section
