npm install @ngrx/store --save


npm i angular-bootstrap

in index.html 

add 

<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.css">
</head>
<body>  
<app-root></app-root>  
<script src="../node_modules/bootstrap/dist/js/bootstrap.js"></script>    

