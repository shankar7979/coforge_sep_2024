package com.cts.exception;

public class BookException extends Exception {
    public BookException(String s) {
        super(s);
    }
}
