package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMain {
    public static void main(String[] args) {
        SpringApplication.run(BookMain.class,args);
    }
}
