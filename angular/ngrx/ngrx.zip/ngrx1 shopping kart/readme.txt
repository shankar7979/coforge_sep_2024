    npm install @angular/animations --save  --legacy-peer-deps
    npm install @ngrx/store @ngrx/effects @ngrx/store-devtools --save  --legacy-peer-deps
	
	https://medium.com/@asiri.l.rajapaksha59/simplifying-ngrx-a-comprehensive-guide-to-state-management-in-angular-3a24b937d2aa

