import logo from './logo.svg';
import './App.css';
import { Allcustomer } from './allcustomer';

function App() {
  return (
    <div>
      <Allcustomer></Allcustomer>
        </div>
  );
}

export default App;
