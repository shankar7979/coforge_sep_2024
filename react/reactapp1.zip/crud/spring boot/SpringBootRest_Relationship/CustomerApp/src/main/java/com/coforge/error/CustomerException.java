package com.coforge.error;

public class CustomerException extends Exception {
    public CustomerException(String msg) {
     super(msg);
    }
}
