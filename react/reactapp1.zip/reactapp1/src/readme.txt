C:\angular\react>set path=c:\node-v20.18.0-win-x64

 this is react software installation 

C:\angular\react>npm i -g create-react-app

this is to create react project
C:\angular\react>npx  create-react-app reactapp1


  cd reactapp1
  npm start