export const Car = [
    { "regno": 776887, "model": "jaguar", "cost": 4500000 },
    { "regno": 776881, "model": "fortuner", "cost": 5500000 },
    { "regno": 776882, "model": "bmw", "cost": 4500000 },
    { "regno": 776883, "model": "scorpion", "cost": 2200000 },
    { "regno": 776884, "model": "thar", "cost": 1700000 },
    { "regno": 776886, "model": "audi", "cost": 1500000 },
]