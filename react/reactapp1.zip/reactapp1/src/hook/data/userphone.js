export const phone=[
    {
        "regno":98898998,
        "model":"samsung",
        "cost":12000
    },
    
    {
        "regno":98898991,
        "model":"nokia",
        "cost":15000
    },
    {
        "regno":98898993,
        "model":"realme",
        "cost":10000
    },
    {
        "regno":98898995,
        "model":"infinix",
        "cost":20000
    },

] 