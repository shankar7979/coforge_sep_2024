export const address={
     addr_id:877887,
     location:"laxminagar",
     city:"new delhi",
     state:"delhi"
}